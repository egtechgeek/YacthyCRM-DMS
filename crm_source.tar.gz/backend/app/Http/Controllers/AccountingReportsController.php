<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AccountingReportsController extends Controller
{
    //
}
